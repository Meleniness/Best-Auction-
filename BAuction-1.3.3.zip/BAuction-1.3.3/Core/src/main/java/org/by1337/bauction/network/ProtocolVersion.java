package org.by1337.bauction.network;

public enum ProtocolVersion {
    V107,
    V108,
    V109,
    V110;

    public static final ProtocolVersion current = V110;
}
