package org.by1337.bauction.event;

public enum EventType {
    SELL_ITEM,
    BUY_ITEM,
    BUY_ITEM_COUNT,
    TAKE_ITEM,
    TAKE_UNSOLD_ITEM,
    EXPIRED_ITEM,
    BUY_ITEM_TO_SELLER,
    BUY_ITEM_COUNT_SELLER,
}
