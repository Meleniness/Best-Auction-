package org.by1337.bauction.api;
@Deprecated(forRemoval = true)
public interface SyncDetector {
    boolean isSync();
}
