package org.by1337.bauction.api.auc;

import org.bukkit.inventory.ItemStack;

public interface ItemHolder {
    ItemStack getItemStack();
}
